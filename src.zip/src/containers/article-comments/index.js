import { memo, useState } from 'react';
import ItemComment from '../../components/item-comment';
import CommentForm from '../../components/comment-form';
import Comments from '../../components/comments';
import useTranslate from '../../hooks/use-translate';
import { useDispatch, useSelector as useSelectorRedux } from 'react-redux';
import useInit from '../../hooks/use-init';
import { useParams } from 'react-router-dom';
import listToTree from '../../utils/list-to-tree';

function ArticleComments() {
  const { t } = useTranslate();
  const [isOpenNewComment, setIsOpenNewComment] = useState(false);

  const selectRedux = useSelectorRedux(state => ({
    comments: state.comments.list,
  }));

  const onOpenReply = () => {
    setIsOpenNewComment(!isOpenNewComment);
    console.log(isOpenNewComment);
  };
  const commentsList = selectRedux.comments;

  console.log(commentsList, listToTree(selectRedux.comments, parent._id));
  return (
    <Comments t={t} count={commentsList.length}>
      {/* <ItemComment t={t} /> */}
      <CommentForm t={t} />
      {commentsList.map(comment => (
        <div key={comment._id}>
          <ItemComment t={t} comment={comment} onOpenReply={onOpenReply} />
          <CommentForm t={t} isOpen={isOpenNewComment}/>
        </div>
      ))}
    </Comments>
  );
}

ArticleComments.propTypes = {};

export default memo(ArticleComments);
