import { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { cn as bem } from '@bem-react/classname';
import './style.css';
import dateFormat from '../../utils/date-format';

function ItemComment(props) {
  const { t = text => text, onOpenReply = () => {}, comment = {} } = props;
  const cn = bem('ItemComment');

  const createDate = date => {
    dateFormat(date);
  };

  const handleClickReply = (e) => {
    e.preventDefault;
    onOpenReply()
  }
  // new Date(jsonDate).toUTCString()
  const newDate = new Date('2024-10-08T19:33:32.065Z');
  // year: 'numeric', month: 'long', day: 'numeric'
  console.log(newDate.getHours());
  return (
    <div className={cn()}>
      <div className={cn('head')}>
        <h3 className={cn('author')}>{comment.author.profile.name}</h3>
        <span className={cn('date')}>25 августа 2022 в 14:00</span>
      </div>
      <p className={cn('text')}>{comment.text}</p>
      <button className={cn('reply-btn')} onClick={handleClickReply}>
        {t('comment.replyBtn')}
      </button>
    </div>
  );
}

ItemComment.propTypes = {};

export default memo(ItemComment);
