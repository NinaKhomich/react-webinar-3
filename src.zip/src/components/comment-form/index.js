import { memo } from 'react';
import PropTypes from 'prop-types';
import { cn as bem } from '@bem-react/classname';
import './style.css';

function CommentForm(props) {
  const { t = text => text, isOpen } = props;
  const cn = bem('CommentForm');

  return (
    <form className={`${isOpen && cn({ theme: 'open' })} ${cn()}`}>
      <label className={cn('form-title')}>{t('commentForm.title')}</label>
      <textarea className={cn('textarea')} name="text" defaultValue={t('commentForm.text')} />
      <button className={cn('sendBtn')}>{t('comment.sendBtn')}</button>
    </form>
  );
}

CommentForm.propTypes = {};

export default memo(CommentForm);
