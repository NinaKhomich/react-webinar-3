export { default as en } from './en.json';
export { default as ru } from './ru.json';
